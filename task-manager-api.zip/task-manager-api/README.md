# Task Manager REST API

A lightweight RESTful API built with PHP and MySQL for managing tasks and users.

## 🛠️ Tech Stack

- **Backend:** PHP 8.1
- **Database:** MySQL 5.7+
- **Architecture:** MVC + RESTful API
- **Auth:** JWT Token Authentication

## 📁 Project Structure

```
task-manager-api/
├── config/
│   └── Database.php        # Database connection
├── controllers/
│   ├── AuthController.php  # Login / Register
│   └── TaskController.php  # CRUD for tasks
├── models/
│   ├── User.php
│   └── Task.php
├── middleware/
│   └── AuthMiddleware.php  # JWT verification
├── routes/
│   └── api.php             # Route definitions
├── public/
│   └── index.php           # Entry point
├── database.sql            # Database schema
└── README.md
```

## 🚀 Quick Start

### 1. Clone the repository
```bash
git clone https://github.com/petter7226/task-manager-api.git
cd task-manager-api
```

### 2. Import database
```bash
mysql -u root -p < database.sql
```

### 3. Configure database connection
Edit `config/Database.php` with your credentials.

### 4. Start the server
```bash
php -S localhost:8000 -t public
```

## 📡 API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login and get JWT token |

### Tasks (requires JWT token)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/tasks` | Get all tasks |
| POST | `/api/tasks` | Create a task |
| GET | `/api/tasks/{id}` | Get single task |
| PUT | `/api/tasks/{id}` | Update a task |
| DELETE | `/api/tasks/{id}` | Delete a task |

## 📝 Example Requests

### Register
```json
POST /api/auth/register
{
  "username": "petter",
  "email": "petter7226@gmail.com",
  "password": "yourpassword"
}
```

### Create Task
```json
POST /api/tasks
Authorization: Bearer <your_jwt_token>

{
  "title": "Build REST API",
  "description": "Complete the task manager project",
  "status": "in_progress",
  "due_date": "2025-12-31"
}
```

## 📄 License

MIT License
