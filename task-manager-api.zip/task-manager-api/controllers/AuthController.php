<?php

namespace Controllers;

use Models\User;
use Middleware\AuthMiddleware;

class AuthController
{
    private User $userModel;
    private AuthMiddleware $auth;

    public function __construct(User $userModel, AuthMiddleware $auth)
    {
        $this->userModel = $userModel;
        $this->auth      = $auth;
    }

    public function register(): void
    {
        $data = $this->getJsonInput();

        $username = trim($data['username'] ?? '');
        $email    = trim($data['email']    ?? '');
        $password =      $data['password'] ?? '';

        if (!$username || !$email || !$password) {
            $this->respond(400, ['error' => 'username, email and password are required']);
            return;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->respond(400, ['error' => 'Invalid email format']);
            return;
        }

        if (strlen($password) < 6) {
            $this->respond(400, ['error' => 'Password must be at least 6 characters']);
            return;
        }

        if ($this->userModel->findByEmail($email) || $this->userModel->findByUsername($username)) {
            $this->respond(409, ['error' => 'Username or email already exists']);
            return;
        }

        $userId = $this->userModel->create($username, $email, $password);
        $token  = $this->auth->generateToken($userId, $username);

        $this->respond(201, [
            'message' => 'User registered successfully',
            'token'   => $token,
            'user'    => ['id' => $userId, 'username' => $username, 'email' => $email],
        ]);
    }

    public function login(): void
    {
        $data = $this->getJsonInput();

        $email    = trim($data['email']    ?? '');
        $password =      $data['password'] ?? '';

        if (!$email || !$password) {
            $this->respond(400, ['error' => 'email and password are required']);
            return;
        }

        $user = $this->userModel->findByEmail($email);
        if (!$user || !$this->userModel->verifyPassword($password, $user['password'])) {
            $this->respond(401, ['error' => 'Invalid credentials']);
            return;
        }

        $token = $this->auth->generateToken($user['id'], $user['username']);

        $this->respond(200, [
            'message' => 'Login successful',
            'token'   => $token,
            'user'    => ['id' => $user['id'], 'username' => $user['username'], 'email' => $user['email']],
        ]);
    }

    private function getJsonInput(): array
    {
        return json_decode(file_get_contents('php://input'), true) ?? [];
    }

    private function respond(int $code, array $data): void
    {
        http_response_code($code);
        echo json_encode($data);
    }
}
