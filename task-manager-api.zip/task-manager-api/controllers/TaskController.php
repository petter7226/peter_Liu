<?php

namespace Controllers;

use Models\Task;
use Middleware\AuthMiddleware;

class TaskController
{
    private Task $taskModel;
    private AuthMiddleware $auth;

    public function __construct(Task $taskModel, AuthMiddleware $auth)
    {
        $this->taskModel = $taskModel;
        $this->auth      = $auth;
    }

    public function index(): void
    {
        $user  = $this->auth->authenticate();
        $tasks = $this->taskModel->getAllByUser($user['user_id']);
        $this->respond(200, ['data' => $tasks, 'count' => count($tasks)]);
    }

    public function show(int $id): void
    {
        $user = $this->auth->authenticate();
        $task = $this->taskModel->findById($id, $user['user_id']);
        if (!$task) {
            $this->respond(404, ['error' => 'Task not found']);
            return;
        }
        $this->respond(200, ['data' => $task]);
    }

    public function store(): void
    {
        $user = $this->auth->authenticate();
        $data = $this->getJsonInput();

        if (empty($data['title'])) {
            $this->respond(400, ['error' => 'title is required']);
            return;
        }

        $validStatuses = ['pending', 'in_progress', 'completed'];
        if (isset($data['status']) && !in_array($data['status'], $validStatuses, true)) {
            $this->respond(400, ['error' => 'status must be: pending, in_progress, or completed']);
            return;
        }

        $taskId = $this->taskModel->create($user['user_id'], $data);
        $task   = $this->taskModel->findById($taskId, $user['user_id']);

        $this->respond(201, ['message' => 'Task created successfully', 'data' => $task]);
    }

    public function update(int $id): void
    {
        $user = $this->auth->authenticate();
        $data = $this->getJsonInput();

        if (!$this->taskModel->findById($id, $user['user_id'])) {
            $this->respond(404, ['error' => 'Task not found']);
            return;
        }

        if (empty($data['title'])) {
            $this->respond(400, ['error' => 'title is required']);
            return;
        }

        $this->taskModel->update($id, $user['user_id'], $data);
        $task = $this->taskModel->findById($id, $user['user_id']);

        $this->respond(200, ['message' => 'Task updated successfully', 'data' => $task]);
    }

    public function destroy(int $id): void
    {
        $user    = $this->auth->authenticate();
        $deleted = $this->taskModel->delete($id, $user['user_id']);

        if (!$deleted) {
            $this->respond(404, ['error' => 'Task not found']);
            return;
        }

        $this->respond(200, ['message' => 'Task deleted successfully']);
    }

    private function getJsonInput(): array
    {
        return json_decode(file_get_contents('php://input'), true) ?? [];
    }

    private function respond(int $code, array $data): void
    {
        http_response_code($code);
        echo json_encode($data);
    }
}
