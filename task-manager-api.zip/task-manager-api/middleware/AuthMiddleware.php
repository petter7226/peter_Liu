<?php

namespace Middleware;

class AuthMiddleware
{
    private string $secretKey = 'your_jwt_secret_key_change_in_production';

    public function generateToken(int $userId, string $username): string
    {
        $header  = $this->base64UrlEncode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
        $payload = $this->base64UrlEncode(json_encode([
            'user_id'  => $userId,
            'username' => $username,
            'iat'      => time(),
            'exp'      => time() + 86400, // 24 hours
        ]));
        $signature = $this->base64UrlEncode(
            hash_hmac('sha256', "$header.$payload", $this->secretKey, true)
        );
        return "$header.$payload.$signature";
    }

    public function validateToken(string $token): array|false
    {
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            return false;
        }

        [$header, $payload, $signature] = $parts;

        $expectedSig = $this->base64UrlEncode(
            hash_hmac('sha256', "$header.$payload", $this->secretKey, true)
        );
        if (!hash_equals($expectedSig, $signature)) {
            return false;
        }

        $data = json_decode($this->base64UrlDecode($payload), true);
        if (!$data || $data['exp'] < time()) {
            return false;
        }

        return $data;
    }

    public function authenticate(): array
    {
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (!str_starts_with($authHeader, 'Bearer ')) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized: missing token']);
            exit;
        }

        $token = substr($authHeader, 7);
        $data  = $this->validateToken($token);
        if (!$data) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized: invalid or expired token']);
            exit;
        }

        return $data;
    }

    private function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private function base64UrlDecode(string $data): string
    {
        return base64_decode(strtr($data, '-_', '+/'));
    }
}
