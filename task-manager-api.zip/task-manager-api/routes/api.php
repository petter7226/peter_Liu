<?php

use Config\Database;
use Models\User;
use Models\Task;
use Middleware\AuthMiddleware;
use Controllers\AuthController;
use Controllers\TaskController;

// --- Bootstrap ---
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// --- Dependencies ---
$db   = (new Database())->getConnection();
$auth = new AuthMiddleware();

$authController = new AuthController(new User($db), $auth);
$taskController = new TaskController(new Task($db), $auth);

// --- Routing ---
$method = $_SERVER['REQUEST_METHOD'];
$uri    = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri    = rtrim(str_replace('/index.php', '', $uri), '/') ?: '/';
$parts  = explode('/', ltrim($uri, '/'));

// POST /api/auth/register
if ($method === 'POST' && $uri === '/api/auth/register') {
    $authController->register();
    exit;
}

// POST /api/auth/login
if ($method === 'POST' && $uri === '/api/auth/login') {
    $authController->login();
    exit;
}

// GET  /api/tasks
// POST /api/tasks
if ($uri === '/api/tasks') {
    match ($method) {
        'GET'  => $taskController->index(),
        'POST' => $taskController->store(),
        default => respond(405, ['error' => 'Method not allowed']),
    };
    exit;
}

// GET    /api/tasks/{id}
// PUT    /api/tasks/{id}
// DELETE /api/tasks/{id}
if (preg_match('#^/api/tasks/(\d+)$#', $uri, $m)) {
    $id = (int) $m[1];
    match ($method) {
        'GET'    => $taskController->show($id),
        'PUT'    => $taskController->update($id),
        'DELETE' => $taskController->destroy($id),
        default  => respond(405, ['error' => 'Method not allowed']),
    };
    exit;
}

// 404
http_response_code(404);
echo json_encode(['error' => 'Endpoint not found']);

function respond(int $code, array $data): void
{
    http_response_code($code);
    echo json_encode($data);
}
