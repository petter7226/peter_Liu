-- Task Manager API Database Schema
-- Created by Petter | github.com/petter7226

CREATE DATABASE IF NOT EXISTS task_manager CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE task_manager;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(50) NOT NULL UNIQUE,
    email       VARCHAR(100) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tasks table
CREATE TABLE IF NOT EXISTS tasks (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    title       VARCHAR(200) NOT NULL,
    description TEXT,
    status      ENUM('pending', 'in_progress', 'completed') DEFAULT 'pending',
    due_date    DATE,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample data
INSERT INTO users (username, email, password) VALUES
('demo_user', 'demo@example.com', '$2y$10$exampleHashedPasswordHere123456');

INSERT INTO tasks (user_id, title, description, status, due_date) VALUES
(1, 'Setup project structure', 'Initialize the PHP REST API project', 'completed', '2024-01-10'),
(1, 'Implement authentication', 'JWT-based login and register', 'completed', '2024-01-15'),
(1, 'Build task CRUD', 'Create, Read, Update, Delete for tasks', 'in_progress', '2024-01-20'),
(1, 'Write documentation', 'Complete README and API docs', 'pending', '2024-01-25');
