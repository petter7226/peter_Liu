<?php

declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__));

// Autoloader
spl_autoload_register(function (string $class): void {
    $map = [
        'Config\\'      => BASE_PATH . '/config/',
        'Models\\'      => BASE_PATH . '/models/',
        'Controllers\\' => BASE_PATH . '/controllers/',
        'Middleware\\'  => BASE_PATH . '/middleware/',
    ];

    foreach ($map as $namespace => $dir) {
        if (str_starts_with($class, $namespace)) {
            $file = $dir . str_replace('\\', '/', substr($class, strlen($namespace))) . '.php';
            if (file_exists($file)) {
                require_once $file;
                return;
            }
        }
    }
});

require_once BASE_PATH . '/routes/api.php';
